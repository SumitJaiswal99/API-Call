//
//  ViewController.swift
//  APICall
//
//  Created by iPHTech 29 on 29/03/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        indicator.isHidden = true
    }
    
    @IBAction func callAPITab(_ sender: Any) {
        callAPIByTab()
    }
    
    func callAPIByTab() {
        
        let session = URLSession.shared
        let serviceUrl = URL(string: "https://jsonplaceholder.typicode.com/todos/1")
        
        /*
                       let task = session.dataTask(with: serviceUrl!) { (data, response, error) in
                           if error == nil {
                           let httpResponse = response as! HTTPURLResponse
                           if httpResponse.statusCode == 200 {
                             let jsondata = try? JSONSerialization.jsonObject(with: data!, options: .mutableContainers)
                             let result = jsondata as! Dictionary<String, Any>
                             print("id = \(String(describing: result["id"]!))")
                         }
                     }
                 }
         */
        indicator.startAnimating()
        let task = session.dataTask(with: serviceUrl!) { [weak self] (data, response, error) in
            
            if error == nil  {
                
                let httpResponse = response as! HTTPURLResponse
                if httpResponse.statusCode == 200 {
                    let jsonData = try? JSONSerialization.jsonObject(with: data!, options: .mutableContainers)
                    let result = jsonData as! Dictionary<String, Any>
                    print("id = \(String(describing: result["id"]!))")
                    print("\(result["title"])")
                    DispatchQueue.main.async {
                        self?.indicator.stopAnimating()
                        self?.infoLabel.text = "\(result["title"]!)"
                    }
                }
            }
        }
        task.resume()
    }
}
